import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent {


  details: any[] = [
    "We offer a day return policy for all unused items with original tags attached Simply contact our customer service to initiate a return and",
    "we will replace the item with an identical one at no cost to you."

  ];

  


}
